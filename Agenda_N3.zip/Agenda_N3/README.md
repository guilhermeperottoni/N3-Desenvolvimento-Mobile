## Equipe:

Guilherme Perottoni, Ramon Ferreira e Luiz Amboni

## Sobre o app 

Este aplicativo foi desenvolvido para a materia de desenvolvimento de aplicativos mobile, desenvolvido pelos alunos [Guilherme Perottoni, RAmon Ferreira e Luiz Amboni].

A aplicação desenvolvida, é referente a uma agenda de contatos, que contem conexão com banco de dados sqlite no device, salvar contato, editar contato, excluir contato, ligar para o número do contato, upload de fotos para o contato pela foto tirada na hora pela camera, etc.
<br/>

## Funcionalidade

A funcionalidade deste aplicativo, é uma agenda de contatos, onde você cadastra seus contatos com nome, número de telefone, e-mail e foto. Para rodar essa aplicação, usamos o android studio e o emulador de celular ANDROID e IOS, incluimos o contato e as informações fornecidas, ficam salvas no aparelho. 

## Tech Stack

- [Dart](https://dart.dev/)
- [Flutter](https://flutter.dev/)

## Plugins

- [sqflite](https://pub.dev/packages/sqflite)
- [url_launcher](https://pub.dev/packages/url_launcher)
- [image_picker](https://pub.dev/packages/image_picker)

<br/>

<!-- about me  END -->
